Videos for solutions (search each topic by name)
https://www.youtube.com/watch?v=PkZNo7MFNFg&ab_channel=freeCodeCamp.org
